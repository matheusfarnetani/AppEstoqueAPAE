export const environment = {
    production: false,
    apiUrl: 'http://100.24.51.217'
  };
  