export interface ItemEstoque {
    id: number;
    nome: string;
    quantidade: number;
    validade: string;
    status: string;
  }